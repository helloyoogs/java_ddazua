package com.java1.access;

import com.java1.day13.Access;

public class Access3 {
	private void function() {
		Access a = new Access();
		System.out.println(a.getData4());
	}
}
