package com.java1.day05;

import javax.swing.JOptionPane;

public class OperTest {
	public static void main(String[] args) {
		System.out.println(10 == 20);
		System.out.println(10 == 10 && 20 > 30);
		System.out.println(10 == 10 || 20 > 30);
		System.out.println(!(10 > 30));
	}
}






