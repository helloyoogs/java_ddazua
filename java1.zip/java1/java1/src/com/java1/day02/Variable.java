package com.java1.day02;

public class Variable {

	public static void main(String[] args) {
		int x = 10;

	}

}
