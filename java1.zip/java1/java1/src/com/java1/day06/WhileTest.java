package com.java1.day06;

public class WhileTest {
	public static void main(String[] args) {
//		
//		int cnt = 0;		
//		
//		while(cnt != 10) {
//			System.out.println(cnt+1+"�ѵ���");
//			cnt++;
//		}
		
		while(true) {
			System.out.println("�ѵ���");
		}
		
		
	}
}
