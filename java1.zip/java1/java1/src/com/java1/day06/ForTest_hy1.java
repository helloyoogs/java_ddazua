package com.java1.day06;

public class ForTest_hy1 {
	public static void main(String[] args) {
		for (int i = 1; i <= 100; i++) {
			System.out.println(i);
		} //1
		
		System.out.println();
		
		for (int i = 100; i >= 1; i--) {
			System.out.println(i);
		} //2
		
		System.out.println();
		
		for (int i = 0; i <= 100;  i+=2) {
			System.out.println(i);
		} //3
		
		System.out.println();
		
		for (int i = 1; i <= 100;  i+=2) {
			System.out.println(i);
		} //4
		
		System.out.println();
		
		for (int i = 0; i <= 100;  i++) {
			if (i % 3 == 0 && i % 5 == 0) {
				System.out.println(i);				
			}
		} //5
		
		System.out.println();
		
		for (char i = 'A'; i <= 'E'; i++) {
			System.out.println(i);
		} //6
	}
}
