package com.java1.day06;

public class Oper {
	public static void main(String[] args) {
		int money = 1_000_000_000;
		int data = 10;
		//money = money + 5000000;
		money += 5000000;
		
		//data = data + 1;
		//data += 1;
		//������
		System.out.println(--data);
		//������
		//System.out.println(data++);
//		System.out.println(data);
		
		
		
	}
}







