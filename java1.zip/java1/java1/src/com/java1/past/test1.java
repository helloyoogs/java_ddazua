package com.java1.past;

public class test1 {
	public static void main(String[] args) {
		for (int i = 1; i < 7; i++) {
			for (int j = 0; j < 5; j++) {
				System.out.println("*");
			}
		}
	}
}
