package com.java1.day04;

import java.util.Scanner;

public class Input {
	public static void main(String[] args) {
		String name = "";
		String lastName = "";
		Scanner sc = new Scanner(System.in);
		//A.b : A�ȿ� b
		System.out.println("�̸��� ����?");
		name = sc.nextLine();
//		name = sc.next();
//		lastName = sc.next();
		System.out.println(name);
//		System.out.println(lastName);
		
		
	}
}
