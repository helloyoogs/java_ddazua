package com.java1.day19;

public class Board {
	public static void main(String[] args) {
		new Rect().showArea(10, 50);
		new Tri().showArea(30, 15.9);
	}
}
