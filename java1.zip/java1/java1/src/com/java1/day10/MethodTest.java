package com.java1.day10;

public class MethodTest {
	
	int add(int num1, int num2){
		System.out.println("add�޼��� �Դϴ�.");
		return num1+num2;
	}
	
	
	public static void main(String[] args) {
//		System.out.println(add(3, 7));
		MethodTest m = new MethodTest();
		System.out.println(m.add(5, 7));
	}
}








