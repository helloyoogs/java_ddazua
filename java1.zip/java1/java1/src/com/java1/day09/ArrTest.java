package com.java1.day09;

public class ArrTest {
	public static void main(String[] args) {
		int[][] arrData = new int[3][4];

		for (int i = 0; i < 12; i++) {

		}

	}
}
