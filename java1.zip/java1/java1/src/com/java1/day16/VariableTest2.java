package com.java1.day16;

public class VariableTest2 {
	public static void main(String[] args) {
		VariableTest vt = new VariableTest();
		vt.f();
		vt.f();
		vt.f();
		vt.f();
		vt.f();
		vt.f();
		vt.f2();
		vt = new VariableTest();
		vt.f();
		
		
		
	}
}
