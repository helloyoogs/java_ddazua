package com.java1.day16;

public class VariableTest {
	//���� ����
	static int data = 0;
	
	void f() {
		System.out.println(++data);
	}
	
	void f2() {
		data = 20;
	}
	
}
