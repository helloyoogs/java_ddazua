package main;

import function.Manage;

public class Index {
	public static void main(String[] args) {
		Manage m = new Manage();
		m.pms();
	}
}
