package view;

import dao.scoreDAO;

public class View {
	public static void main(String[] args) {
		new scoreDAO().index();
	}
}
