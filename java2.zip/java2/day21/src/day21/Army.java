package day21;

public abstract class Army implements Soldier{
	@Override
	public void eat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void work() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void salute() {
		// TODO Auto-generated method stub
		
	}
}
