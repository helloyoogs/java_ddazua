package day21;

public class Sergent extends Army {
	
	@Override
	public void play() {
		System.out.println("��� ����.");
	}

	@Override
	public void sleep() {
		System.out.println("��� �ܴ�.");
	}
	
	@Override
	public void salute() {
		System.out.println("��");
	}
}
