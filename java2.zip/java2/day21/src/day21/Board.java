package day21;

public class Board {
	public static void main(String[] args) {
		new Rect().draw(10, 50);
		new Tri().draw(30, 5.6);	
		Shape.function();
	}
}
