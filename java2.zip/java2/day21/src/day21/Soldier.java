package day21;

public interface Soldier {
	final static int arm = 2;
	int legs = 2;
	
	public abstract void eat();
	void work();
	void play();
	void sleep();
	void salute();
}
