package marker;

public class Phone4G implements Phone{

	@Override
	public void msg(String str, String tel) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void call(String tel) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void useInternet() {
		System.out.println("���� �ӵ��� �� ����");
	}

}
