package marker;

public class Digimon implements Animation{

}
