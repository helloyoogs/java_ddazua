package marker;

public interface Animation {

}
