package marker;

public class PokeMon implements Animation{

}
