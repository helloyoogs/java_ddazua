package marker;

public class ZzangGu implements Animation{

}
