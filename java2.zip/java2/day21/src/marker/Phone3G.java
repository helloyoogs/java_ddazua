package marker;

public class Phone3G implements Phone{

	@Override
	public void msg(String str, String tel) {
		
		
	}

	@Override
	public void call(String tel) {
		
		
	}
	
	@Override
	public void useInternet() {
		System.out.println("�� ������");
	}

}
