package com.java1.day22;

public interface Cafe {
//�޴���
//�Ǹ�
	void setMenu(String[] menu);

	String[] getMenu();

	void sell(String choice);
}
